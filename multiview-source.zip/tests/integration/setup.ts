import { db } from "@/lib/db";

// Order matters — children before parents, respecting FK constraints.
// Simplest correct approach for a test DB this size; would swap for
// per-test transactions-that-rollback if the suite grows large enough
// for this to be a speed problem.
export async function resetDb() {
  await db.$executeRawUnsafe(`
    TRUNCATE TABLE
      "event_daily_metrics",
      "tournament_incidents",
      "organization_invitations",
      "organization_members",
      "clips",
      "match_events",
      "recordings",
      "watch_history_entries",
      "favorites",
      "matches",
      "stations",
      "brackets",
      "tournament_entrants",
      "tournaments",
      "players",
      "team_members",
      "tournament_teams",
      "teams",
      "organizations",
      "users"
    RESTART IDENTITY CASCADE
  `);
}

export async function createUser(role: "VIEWER" | "ORGANIZER" | "ADMIN" = "VIEWER") {
  return db.user.create({
    data: {
      clerkId: `test-clerk-${crypto.randomUUID()}`,
      email: `${crypto.randomUUID()}@example.test`,
      username: `user-${crypto.randomUUID().slice(0, 8)}`,
      role,
    },
  });
}

export async function createTournament(organizerId: string) {
  const user = await db.user.findUniqueOrThrow({ where: { id: organizerId }, select: { username: true } });
  const organization = await db.organization.create({
    data: {
      name: `${user.username ?? "Test"} Events`,
      slug: `test-org-${crypto.randomUUID().slice(0, 8)}`,
      ownerId: organizerId,
      members: { create: { userId: organizerId, role: "OWNER" } },
    },
  });
  return db.tournament.create({
    data: {
      name: "Test Open 2026",
      slug: `test-open-${crypto.randomUUID().slice(0, 8)}`,
      game: "Street Fighter 6",
      startDate: new Date(),
      organizerId,
      organizationId: organization.id,
    },
  });
}

export async function createPlayer(gamertag: string) {
  return db.player.create({ data: { gamertag } });
}

export async function createStation(tournamentId: string, label = "Station 1") {
  return db.station.create({ data: { tournamentId, label } });
}

export async function createTeam(name: string) {
  return db.team.create({ data: { name, slug: `${name.toLowerCase().replace(/\s+/g, "-")}-${crypto.randomUUID().slice(0, 8)}` } });
}
