"use client";

import { YouTubePlayer } from "./YouTubePlayer";

type MultiViewStation = { id: string; label: string; youtubeVideoId: string | null };

// Multi-view is HLS-only, deliberately — 9 simultaneous WebRTC
// subscriptions is 9x the SFU load per viewer, which is exactly the
// scaling problem the HLS-default decision in STREAMING_ARCHITECTURE.md
// exists to avoid. All streams muted except one at a time (audio from 9
// matches at once isn't useful anyway); click a tile to make it the
// audio focus.
export function MultiView({
  stations,
  layout,
}: {
  stations: MultiViewStation[];
  layout: 4 | 9;
}) {
  const visible = stations.slice(0, layout);
  // Fixed 2/3-column grids read fine on a desktop monitor but turn into
  // postage-stamp tiles on a phone (fighting-game viewership skews heavily
  // mobile) — collapse to a single column below `sm`, then step up to the
  // full desktop column count.
  const gridClass =
    layout === 4 ? "grid-cols-1 sm:grid-cols-2" : "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3";

  return (
    <div className={`grid gap-2 ${gridClass}`}>
      {visible.map((s, i) =>
        s.youtubeVideoId ? (
          <div key={s.id} className="relative">
            <YouTubePlayer stationId={s.id} videoId={s.youtubeVideoId} isLive={true} muted={i !== 0} />
            <span className="absolute left-2 top-2 rounded bg-arena-950/80 px-1.5 py-0.5 font-mono text-[10px] uppercase text-ink-muted">
              {s.label}
            </span>
          </div>
        ) : (
          <div key={s.id} className="flex aspect-video items-center justify-center rounded-card bg-arena-900 text-xs text-ink-faint">
            {s.label} — offline
          </div>
        )
      )}
    </div>
  );
}
